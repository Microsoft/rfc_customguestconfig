
Configuration Server2019Baseline
{

	Import-DSCResource -ModuleName 'PSDscResources'
	Import-DSCResource -ModuleName 'AuditPolicyDSC'
	Import-DSCResource -ModuleName 'SecurityPolicyDSC'
	# Module Not Found: Import-DSCResource -ModuleName 'PowerShellAccessControl'
	Node localhost
	{
         AuditPolicySubcategory 'Audit Credential Validation (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'Credential Validation'

         }

          AuditPolicySubcategory 'Audit Credential Validation (Failure) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Failure'
              Name = 'Credential Validation'

         }

         AuditPolicySubcategory 'Audit Security Group Management (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'Security Group Management'

         }

          AuditPolicySubcategory 'Audit Security Group Management (Failure) - Inclusion'
         {
              Ensure = 'Absent'
              AuditFlag = 'Failure'
              Name = 'Security Group Management'

         }

         AuditPolicySubcategory 'Audit User Account Management (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'User Account Management'

         }

          AuditPolicySubcategory 'Audit User Account Management (Failure) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Failure'
              Name = 'User Account Management'

         }

         AuditPolicySubcategory 'Audit PNP Activity (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'Plug and Play Events'

         }

          AuditPolicySubcategory 'Audit PNP Activity (Failure) - Inclusion'
         {
              Ensure = 'Absent'
              AuditFlag = 'Failure'
              Name = 'Plug and Play Events'

         }

         AuditPolicySubcategory 'Audit Process Creation (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'Process Creation'

         }

          AuditPolicySubcategory 'Audit Process Creation (Failure) - Inclusion'
         {
              Ensure = 'Absent'
              AuditFlag = 'Failure'
              Name = 'Process Creation'

         }

         AuditPolicySubcategory 'Audit Account Lockout (Failure) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Failure'
              Name = 'Account Lockout'

         }

          AuditPolicySubcategory 'Audit Account Lockout (Success) - Inclusion'
         {
              Ensure = 'Absent'
              AuditFlag = 'Success'
              Name = 'Account Lockout'

         }

         AuditPolicySubcategory 'Audit Group Membership (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'Group Membership'

         }

          AuditPolicySubcategory 'Audit Group Membership (Failure) - Inclusion'
         {
              Ensure = 'Absent'
              AuditFlag = 'Failure'
              Name = 'Group Membership'

         }

         AuditPolicySubcategory 'Audit Logon (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'Logon'

         }

          AuditPolicySubcategory 'Audit Logon (Failure) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Failure'
              Name = 'Logon'

         }

         AuditPolicySubcategory 'Audit Other Logon/Logoff Events (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'Other Logon/Logoff Events'

         }

          AuditPolicySubcategory 'Audit Other Logon/Logoff Events (Failure) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Failure'
              Name = 'Other Logon/Logoff Events'

         }

         AuditPolicySubcategory 'Audit Special Logon (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'Special Logon'

         }

          AuditPolicySubcategory 'Audit Special Logon (Failure) - Inclusion'
         {
              Ensure = 'Absent'
              AuditFlag = 'Failure'
              Name = 'Special Logon'

         }

         AuditPolicySubcategory 'Audit Detailed File Share (Failure) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Failure'
              Name = 'Detailed File Share'

         }

          AuditPolicySubcategory 'Audit Detailed File Share (Success) - Inclusion'
         {
              Ensure = 'Absent'
              AuditFlag = 'Success'
              Name = 'Detailed File Share'

         }

         AuditPolicySubcategory 'Audit File Share (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'File Share'

         }

          AuditPolicySubcategory 'Audit File Share (Failure) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Failure'
              Name = 'File Share'

         }

         AuditPolicySubcategory 'Audit Other Object Access Events (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'Other Object Access Events'

         }

          AuditPolicySubcategory 'Audit Other Object Access Events (Failure) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Failure'
              Name = 'Other Object Access Events'

         }

         AuditPolicySubcategory 'Audit Removable Storage (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'Removable Storage'

         }

          AuditPolicySubcategory 'Audit Removable Storage (Failure) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Failure'
              Name = 'Removable Storage'

         }

         AuditPolicySubcategory 'Audit Audit Policy Change (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'Audit Policy Change'

         }

          AuditPolicySubcategory 'Audit Audit Policy Change (Failure) - Inclusion'
         {
              Ensure = 'Absent'
              AuditFlag = 'Failure'
              Name = 'Audit Policy Change'

         }

         AuditPolicySubcategory 'Audit Authentication Policy Change (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'Authentication Policy Change'

         }

          AuditPolicySubcategory 'Audit Authentication Policy Change (Failure) - Inclusion'
         {
              Ensure = 'Absent'
              AuditFlag = 'Failure'
              Name = 'Authentication Policy Change'

         }

         AuditPolicySubcategory 'Audit MPSSVC Rule-Level Policy Change (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'MPSSVC Rule-Level Policy Change'

         }

          AuditPolicySubcategory 'Audit MPSSVC Rule-Level Policy Change (Failure) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Failure'
              Name = 'MPSSVC Rule-Level Policy Change'

         }

         AuditPolicySubcategory 'Audit Other Policy Change Events (Failure) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Failure'
              Name = 'Other Policy Change Events'

         }

          AuditPolicySubcategory 'Audit Other Policy Change Events (Success) - Inclusion'
         {
              Ensure = 'Absent'
              AuditFlag = 'Success'
              Name = 'Other Policy Change Events'

         }

         AuditPolicySubcategory 'Audit Sensitive Privilege Use (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'Sensitive Privilege Use'

         }

          AuditPolicySubcategory 'Audit Sensitive Privilege Use (Failure) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Failure'
              Name = 'Sensitive Privilege Use'

         }

         AuditPolicySubcategory 'Audit Other System Events (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'Other System Events'

         }

          AuditPolicySubcategory 'Audit Other System Events (Failure) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Failure'
              Name = 'Other System Events'

         }

         AuditPolicySubcategory 'Audit Security State Change (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'Security State Change'

         }

          AuditPolicySubcategory 'Audit Security State Change (Failure) - Inclusion'
         {
              Ensure = 'Absent'
              AuditFlag = 'Failure'
              Name = 'Security State Change'

         }

         AuditPolicySubcategory 'Audit Security System Extension (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'Security System Extension'

         }

          AuditPolicySubcategory 'Audit Security System Extension (Failure) - Inclusion'
         {
              Ensure = 'Absent'
              AuditFlag = 'Failure'
              Name = 'Security System Extension'

         }

         AuditPolicySubcategory 'Audit System Integrity (Success) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Success'
              Name = 'System Integrity'

         }

          AuditPolicySubcategory 'Audit System Integrity (Failure) - Inclusion'
         {
              Ensure = 'Present'
              AuditFlag = 'Failure'
              Name = 'System Integrity'

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Profile_single_process'
         {
              Identity = @('*S-1-5-32-544')
              Policy = 'Profile_single_process'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Load_and_unload_device_drivers'
         {
              Identity = @('*S-1-5-32-544')
              Policy = 'Load_and_unload_device_drivers'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Take_ownership_of_files_or_other_objects'
         {
              Identity = @('*S-1-5-32-544')
              Policy = 'Take_ownership_of_files_or_other_objects'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Back_up_files_and_directories'
         {
              Identity = @('*S-1-5-32-544')
              Policy = 'Back_up_files_and_directories'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Create_a_token_object'
         {
              Identity = @('')
              Policy = 'Create_a_token_object'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Enable_computer_and_user_accounts_to_be_trusted_for_delegation'
         {
              Identity = @('')
              Policy = 'Enable_computer_and_user_accounts_to_be_trusted_for_delegation'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Modify_firmware_environment_values'
         {
              Identity = @('*S-1-5-32-544')
              Policy = 'Modify_firmware_environment_values'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Deny_log_on_through_Remote_Desktop_Services'
         {
              Identity = @('*S-1-5-113')
              Policy = 'Deny_log_on_through_Remote_Desktop_Services'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Access_this_computer_from_the_network'
         {
              Identity = @('*S-1-5-32-544', '*S-1-5-11')
              Policy = 'Access_this_computer_from_the_network'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Perform_volume_maintenance_tasks'
         {
              Identity = @('*S-1-5-32-544')
              Policy = 'Perform_volume_maintenance_tasks'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Allow_log_on_locally'
         {
              Identity = @('*S-1-5-32-544')
              Policy = 'Allow_log_on_locally'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Access_Credential_Manager_as_a_trusted_caller'
         {
              Identity = @('')
              Policy = 'Access_Credential_Manager_as_a_trusted_caller'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Manage_auditing_and_security_log'
         {
              Identity = @('*S-1-5-32-544')
              Policy = 'Manage_auditing_and_security_log'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Create_global_objects'
         {
              Identity = @('*S-1-5-32-544', '*S-1-5-6', '*S-1-5-19', '*S-1-5-20')
              Policy = 'Create_global_objects'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Restore_files_and_directories'
         {
              Identity = @('*S-1-5-32-544')
              Policy = 'Restore_files_and_directories'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Lock_pages_in_memory'
         {
              Identity = @('')
              Policy = 'Lock_pages_in_memory'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Create_a_pagefile'
         {
              Identity = @('*S-1-5-32-544')
              Policy = 'Create_a_pagefile'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Act_as_part_of_the_operating_system'
         {
              Identity = @('')
              Policy = 'Act_as_part_of_the_operating_system'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Create_permanent_shared_objects'
         {
              Identity = @('')
              Policy = 'Create_permanent_shared_objects'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Deny_access_to_this_computer_from_the_network'
         {
              Identity = @('*S-1-5-114')
              Policy = 'Deny_access_to_this_computer_from_the_network'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Force_shutdown_from_a_remote_system'
         {
              Identity = @('*S-1-5-32-544')
              Policy = 'Force_shutdown_from_a_remote_system'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Debug_programs'
         {
              Identity = @('*S-1-5-32-544')
              Policy = 'Debug_programs'
              Force = $True

         }

         UserRightsAssignment 'UserRightsAssignment(INF): Impersonate_a_client_after_authentication'
         {
              Identity = @('*S-1-5-32-544', '*S-1-5-6', '*S-1-5-19', '*S-1-5-20')
              Policy = 'Impersonate_a_client_after_authentication'
              Force = $True

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\LanmanWorkstation\Parameters\RequireSecuritySignature'
         {
              ValueData = 1
              Key = 'HKLM:\System\CurrentControlSet\Services\LanmanWorkstation\Parameters'
              ValueType = 'Dword'
              ValueName = 'RequireSecuritySignature'

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\SCENoApplyLegacyAuditPolicy'
         {
              ValueData = 1
              Key = 'HKLM:\System\CurrentControlSet\Control\Lsa'
              ValueType = 'Dword'
              ValueName = 'SCENoApplyLegacyAuditPolicy'

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\LimitBlankPasswordUse'
         {
              ValueData = 1
              Key = 'HKLM:\System\CurrentControlSet\Control\Lsa'
              ValueType = 'Dword'
              ValueName = 'LimitBlankPasswordUse'

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters\requirestrongkey'
         {
              ValueData = 1
              Key = 'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters'
              ValueType = 'Dword'
              ValueName = 'requirestrongkey'

         }

         Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\FilterAdministratorToken'
         {
              ValueData = 1
              Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
              ValueType = 'Dword'
              ValueName = 'FilterAdministratorToken'

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\LDAP\LDAPClientIntegrity'
         {
              ValueData = 1
              Key = 'HKLM:\System\CurrentControlSet\Services\LDAP'
              ValueType = 'Dword'
              ValueName = 'LDAPClientIntegrity'

         }

         Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableInstallerDetection'
         {
              ValueData = 1
              Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
              ValueType = 'Dword'
              ValueName = 'EnableInstallerDetection'

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\LmCompatibilityLevel'
         {
              ValueData = 5
              Key = 'HKLM:\System\CurrentControlSet\Control\Lsa'
              ValueType = 'Dword'
              ValueName = 'LmCompatibilityLevel'

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\LanmanWorkstation\Parameters\EnablePlainTextPassword'
         {
              ValueData = 0
              Key = 'HKLM:\System\CurrentControlSet\Services\LanmanWorkstation\Parameters'
              ValueType = 'Dword'
              ValueName = 'EnablePlainTextPassword'

         }

         Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableLUA'
         {
              ValueData = 1
              Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
              ValueType = 'Dword'
              ValueName = 'EnableLUA'

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters\requiresecuritysignature'
         {
              ValueData = 1
              Key = 'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters'
              ValueType = 'Dword'
              ValueName = 'requiresecuritysignature'

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\RestrictRemoteSAM'
         {
              ValueData = 'O:BAG:BAD:(A;;RC;;;BA)'
              Key = 'HKLM:\System\CurrentControlSet\Control\Lsa'
              ValueType = 'String'
              ValueName = 'RestrictRemoteSAM'

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Session Manager\ProtectionMode'
         {
              ValueData = 1
              Key = 'HKLM:\System\CurrentControlSet\Control\Session Manager'
              ValueType = 'Dword'
              ValueName = 'ProtectionMode'

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters\requiresignorseal'
         {
              ValueData = 1
              Key = 'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters'
              ValueType = 'Dword'
              ValueName = 'requiresignorseal'

         }

         Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\InactivityTimeoutSecs'
         {
              ValueData = 900
              Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
              ValueType = 'Dword'
              ValueName = 'InactivityTimeoutSecs'

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters\sealsecurechannel'
         {
              ValueData = 1
              Key = 'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters'
              ValueType = 'Dword'
              ValueName = 'sealsecurechannel'

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters\RestrictNullSessAccess'
         {
              ValueData = 1
              Key = 'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters'
              ValueType = 'Dword'
              ValueName = 'RestrictNullSessAccess'

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\NoLMHash'
         {
              ValueData = 1
              Key = 'HKLM:\System\CurrentControlSet\Control\Lsa'
              ValueType = 'Dword'
              ValueName = 'NoLMHash'

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0\NTLMMinClientSec'
         {
              ValueData = 537395200
              Key = 'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0'
              ValueType = 'Dword'
              ValueName = 'NTLMMinClientSec'

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\RestrictAnonymousSAM'
         {
              ValueData = 1
              Key = 'HKLM:\System\CurrentControlSet\Control\Lsa'
              ValueType = 'Dword'
              ValueName = 'RestrictAnonymousSAM'

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\RestrictAnonymous'
         {
              ValueData = 1
              Key = 'HKLM:\System\CurrentControlSet\Control\Lsa'
              ValueType = 'Dword'
              ValueName = 'RestrictAnonymous'

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0\allownullsessionfallback'
         {
              ValueData = 0
              Key = 'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0'
              ValueType = 'Dword'
              ValueName = 'allownullsessionfallback'

         }

         Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableSecureUIAPaths'
         {
              ValueData = 1
              Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
              ValueType = 'Dword'
              ValueName = 'EnableSecureUIAPaths'

         }

         Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\ConsentPromptBehaviorAdmin'
         {
              ValueData = 2
              Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
              ValueType = 'Dword'
              ValueName = 'ConsentPromptBehaviorAdmin'

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters\signsecurechannel'
         {
              ValueData = 1
              Key = 'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters'
              ValueType = 'Dword'
              ValueName = 'signsecurechannel'

         }

         Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\ConsentPromptBehaviorUser'
         {
              ValueData = 0
              Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
              ValueType = 'Dword'
              ValueName = 'ConsentPromptBehaviorUser'

         }

         Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon\ScRemoveOption'
         {
              ValueData = '1'
              Key = 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon'
              ValueType = 'String'
              ValueName = 'ScRemoveOption'

         }

         Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0\NTLMMinServerSec'
         {
              ValueData = 537395200
              Key = 'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0'
              ValueType = 'Dword'
              ValueName = 'NTLMMinServerSec'

         }

         Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableVirtualization'
         {
              ValueData = 1
              Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
              ValueType = 'Dword'
              ValueName = 'EnableVirtualization'

         }

         SecurityOption 'SecuritySetting(INF): LSAAnonymousNameLookup'
         {
              Network_access_Allow_anonymous_SID_Name_translation = 'Disabled'
              Name = 'Network_access_Allow_anonymous_SID_Name_translation'

         }

	}
}
Server2019Baseline -OutputPath 'v:\policyfiles\'
